package com.kilobolt.mweso;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class GamePlay3 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_play3);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game_play3, menu);
		return true;
	}

}
