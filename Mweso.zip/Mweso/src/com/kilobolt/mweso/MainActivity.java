package com.kilobolt.mweso;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void gotoplay(View v) {
		Intent intent = new Intent(this, Play.class);
		startActivity(intent);
	}
	
	public void gotoboard(View v) {
		Intent intent = new Intent(this, Board.class);
		startActivity(intent);
	}

	public void gotoOptions(View v) {
		Intent intent = new Intent(this, Options.class);
		startActivity(intent);
	}
	
	public void gotoInstructions(View v) {
		Intent intent = new Intent(this, Instructions.class);
		startActivity(intent);
	}
	/*
	public void gotoUpcomingEvents(View v) {
		Intent intent = new Intent(this, UpcomingEventsActivity.class);
		startActivity(intent);
	}

	public void testNotifier(View v) {
		Intent intent = new Intent("com.st.fn.NOTIFY");
		this.sendBroadcast(intent);
	}
	*/
	
	public void clickExit(View v){
		//Exit
		finish();
	}
	@Override
	public void onBackPressed(){
		
		//Exit dialog
		AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
		builder.setMessage("Do you want to Exit?");
		builder.setTitle("Confirmation!");
		builder.setCancelable(true);
		builder.setPositiveButton("OK", new OnClickListener(){
			
			
			@Override
			public void onClick(DialogInterface dialog, int id){
				
				finish();
			}
		});
		
		builder.setNegativeButton("Cancel", new OnClickListener(){
			
			@Override
			public void onClick(DialogInterface dialog, int id){
				
				dialog.cancel();
				
			}
		});
		
		AlertDialog alert = builder.create();
		alert.show();
	}

	protected void onResume(){	
		
		super.onResume();
	}
	
	protected void onPause(){
		
		super.onPause();
	}
	
	
}

