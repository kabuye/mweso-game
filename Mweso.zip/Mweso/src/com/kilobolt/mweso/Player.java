package com.kilobolt.mweso;

public enum Player {
	NO_PLAYER(-1),
	PLAYER1(1),
	PLAYER2(2);
	
	private int id;
	
	private Player(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
}
