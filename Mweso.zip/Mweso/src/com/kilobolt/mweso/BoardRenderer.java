package com.kilobolt.mweso;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;

/**
 * Used to render the board to the screen.  Also contains utility functions for translating regular
 * coordinates to board coordinates. 
 * 
 * @author Kris Healy
 *
 */
public class BoardRenderer {
	private static final int SQUARE_SIZE = 148;
	
	private Bitmap boardImage;
	private Bitmap redPieceImage;
	private Bitmap bluePieceImage;
	
	private Point ghostPiece;
	
	public Point getGhostPiece() {
		return ghostPiece;
	}

	public void setGhostPiece(Point ghostPiece) {
		this.ghostPiece = ghostPiece;
	}

	public BoardRenderer(Resources res) {
		boardImage = BitmapFactory.decodeResource(res, R.drawable.board);
		redPieceImage = BitmapFactory.decodeResource(res, R.drawable.red_piece);
		bluePieceImage = BitmapFactory.decodeResource(res, R.drawable.blue_piece);
	}
	
	private Bitmap getPlayerDrawable(Player player) {
		if(player.equals(Player.PLAYER1)) {
			return bluePieceImage;
		} else if(player.equals(Player.PLAYER2)) {
			return redPieceImage;
		}
		
		return null;
	}

	/**
	 * Renders the game board to a canvas.
	 * 
	 * @param canvas
	 * @param gameBoard
	 */
	public void render(Canvas canvas, GameBoard gameBoard) {
		Rect dst = new Rect(0, 0, boardImage.getWidth(), boardImage.getHeight());
		canvas.drawBitmap(boardImage, null, dst, null);
		
		if(gameBoard == null) {
			return;
		}
		
		for(int x = 0; x < gameBoard.getWidth(); x++) {
			for(int y = 0; y < gameBoard.getHeight(); y++) {
				if(gameBoard.hasPiece(x, y)) {
					Bitmap bmp = getPlayerDrawable(gameBoard.get(x, y));
					
					int left = SQUARE_SIZE * x;
					int top = SQUARE_SIZE * y;
					
					dst = new Rect(left,
							       top,
							       bmp.getWidth() + left,
							       bmp.getHeight() + top);
					
					canvas.drawBitmap(bmp, null, dst, null);
				} else if(ghostPiece != null && ghostPiece.x == x && ghostPiece.y == y) {
					Bitmap bmp = getPlayerDrawable(Player.PLAYER1);
					
					int left = SQUARE_SIZE * ghostPiece.x;
					int top = SQUARE_SIZE * ghostPiece.y;
					
					dst = new Rect(left,
							       top,
							       bmp.getWidth() + left,
							       bmp.getHeight() + top);
					
					Paint paint = new Paint();
					paint.setAlpha(128);
					
					canvas.drawBitmap(bmp, null, dst, paint);
				}
			}
		}
	}
	
	/**
	 * Translate's a (x, y) in pixels to board coordinates.  Returns null
	 * if out of bounds.
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public Point translatePixelToBoardCoordinates(GameBoard board, int x, int y) {
		x = (int)(((x * 1.0) / getTouchableWidth()) * board.getWidth());
		y = (int)(((y * 1.0) / getTouchableHeight()) * board.getHeight());
		
		if(x < 0 || x > (board.getWidth() - 1) || y < 0 || y > (board.getHeight() - 1)) {
			return null;
		}
		
		return new Point(x, y);
	}
	
	/**
	 * Gets the area (wide) that can be effected by ontouch events.
	 * @return
	 * 	Touchable area's width
	 */
	public int getTouchableWidth() {
		return boardImage.getWidth();
	}
	
	/**
	 * Gets the height of the area that is effected by ontouch events.
	 * 
	 * @return
	 * 	Touchable area's height.
	 */
	public int getTouchableHeight() {
		return boardImage.getHeight();
	}
}
