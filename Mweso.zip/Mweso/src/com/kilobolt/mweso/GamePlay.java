package com.kilobolt.mweso;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class GamePlay extends Activity implements OnClickListener{
	
	Button a1, a2, a3, b1, b2, b3, c1, c2, c3, bNewGame;
	Button[] bArray;
	
	boolean turn = true; 
	// X = true, O = false
	
	int turn_count = 0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gameplay);
		
		//Link buttons to the layout file
		a1 = (Button)findViewById(R.id.A1);
		a2 = (Button)findViewById(R.id.A2);
		a3 = (Button)findViewById(R.id.A3);
		b1 = (Button)findViewById(R.id.B1);
		b2 = (Button)findViewById(R.id.B2);
		b3 = (Button)findViewById(R.id.B3);
		c1 = (Button)findViewById(R.id.C1);
		c2 = (Button)findViewById(R.id.C2);
		c3 = (Button)findViewById(R.id.C3);
		//bNewGame = (Button) findViewById(R.id.bNewGame);
		
		//Create the array to store all buttons and register their respective events listeners
		bArray = new Button[]{a1, a2, a3, b1, b2, b3, c1, c2, c3};
		
		//Set the onclick listener for every Button b in the array bArray
		for(Button b : bArray){
			
			b.setOnClickListener(this); //'this' makes the class as the handler for the event
			
		}
		
		//We use anonymous inner class concept here
		/*
		bNewGame.setOnClickListener(new OnClickListener(){
			
			public void onClick(View v){
				//Function is called when new game button is clicked
				
				//Reset turn and turn count and Re-enable all buttons
				
				turn = true;
				turn_count = 0;
				enabledisableAllButtons(true);
				
			}
		
		});
		
		*/
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return true;
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		Button b = (Button) v;
		buttonClicked(b);
		
		
	}
	

	
	public void buttonClicked(Button b){
		
		//At the start of the game turn is true. So game always starts with X's turn
		
		//We just want to change the text on the button to X/O
		
		
		if(turn){
			if(b.toString() != null){
			
			b.setText(null);
			
			}else {
				
				b.setText("X");
			}
			
		}
		else{
			
			// O's turn
			b.setText("O");
		}
		
		
		turn_count++;
		
		//Just to be clear, we change the color too
		b.setBackgroundColor(Color.LTGRAY);
		
		//Disable the button for further clicks
		b.setClickable(false);
		
		//and change the turn
		turn = !turn;
		
		//Now we check for winner after every round
		checkForWinner();
		
			
			b.setClickable(false);	
			
		
		}
	
	
	private void checkForWinner(){
		
		boolean there_is_a_winner = false;
		
		//First we check the horizontals
		if(a1.getText() == a2.getText() && a2.getText() == a3.getText() && !a1.isClickable()){
			
			there_is_a_winner = true;
		}
		else if(b1.getText() == b2.getText() && b2.getText() == b3.getText() && !b1.isClickable()){
			
			there_is_a_winner = true;
		}
		
		else if(c1.getText() == c2.getText() && c2.getText() == c3.getText() && !c1.isClickable()){
			
			there_is_a_winner = true;
		}
		
		//then the verticles 
if(a1.getText() == b1.getText() && b1.getText() == c1.getText() && !a1.isClickable()){
			
			there_is_a_winner = true;
		}
		else if(a2.getText() == b2.getText() && b2.getText() == c2.getText() && !b2.isClickable()){
			
			there_is_a_winner = true;
		}
		
		else if(a3.getText() == b3.getText() && b3.getText() == c3.getText() && !c3.isClickable()){
			
			there_is_a_winner = true;
		}		
		
		//and then the two diagonals
if(a1.getText() == b2.getText() && b2.getText() == c3.getText() && !a1.isClickable()){
	
	there_is_a_winner = true;
}
else if(a3.getText() == b2.getText() && b2.getText() == c1.getText() && !b2.isClickable()){
	
	there_is_a_winner = true;
}

	
		if(there_is_a_winner){
			
			//because O just played and the turn was reversed
			if(!turn){
				
				toast("X Wins");
			}
			else{
				
				toast("O Wins");
			}
			
			//Generic method for enabling and disabling
			enabledisableAllButtons(false); // send a false to the func.
			
		}
		
		//Handle draws
		else if(turn_count == 6){
			//When all the buttons are clicked and disabled
			toast("DRAW");
			
		}
		
		
		
		
		
	}
	
	private void enabledisableAllButtons(boolean enable) {
		// TODO Auto-generated method stub
		
		//false to disable
		for(Button b : bArray){
			
			b.setClickable(enable);
			//false
			
			//for the color
			if(enable){
				
				b.setBackgroundColor(Color.parseColor("#33b5e5"));
				
				//set the text back to blank
				b.setText("");
				
			}
			
			else{
				b.setBackgroundColor(Color.LTGRAY);
			}
		}
		
	}

	private void toast(String message){
		
		Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
		
		
	}
	
	 @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        switch (item.getItemId()) {
	            case R.id.item1:
	            	Intent intent = new Intent(this, MainActivity.class);
	        		startActivity(intent);
	            	//Toast.makeText(getApplicationContext(),"Item 1 Selected",Toast.LENGTH_LONG).show();
	            return true;   

	            case R.id.item2:
	                Toast.makeText(getApplicationContext(),"Item 2 Selected",Toast.LENGTH_LONG).show();
	              return true;     

	              default:
	                return super.onOptionsItemSelected(item);
	        }
	    }

}
