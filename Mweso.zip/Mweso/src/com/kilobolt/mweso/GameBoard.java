package com.kilobolt.mweso;

import java.util.LinkedList;
import java.util.List;

import android.R.array;
import android.graphics.Point;

/**
 * Represents a basic tic-tac-toe board.
 * 
 * @author Kris Healy
 */
public class GameBoard {
	private Player[][] contents;
	public static final int width=3;
	public static final int height=3;
	private List<Point> emptySpots;

	
	
	public GameBoard(int width, int height) {
		//this.width = width;
		//this.height = height;
		
		emptySpots = new LinkedList<Point>();
		
		clear();
	}

	public void clear() {
		emptySpots.clear();
		contents = new Player[width][height];
		
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y++) {
				contents[x][y] = Player.NO_PLAYER;
				emptySpots.add(new Point(x, y));
			}
		}
	}
	
	/**
	 * Places a board piece.
	 * 
	 * @param player
	 * 	Which player is being placed
	 * @return
	 * 	True if success, false if a piece already exists there.
	 */
	public boolean put(Player player, int x, int y) {
		if(hasPiece(x, y)) {
			return false;
		}
		
		contents[x][y] = player;
		emptySpots.remove(new Point(x, y));
		
		return true;
	}
	
	/**
	 * Returns true if a piece has already been placed on the x, y point.
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean hasPiece(int x, int y) {
		return contents[x][y] != Player.NO_PLAYER;
	}
	
	/**
	 * Gets the piece on the x, y point.
	 * @param x
	 * @param y
	 * @return
	 * 	The player, or 0 if no player.
	 */
	public Player get(int x, int y) {
		return contents[x][y];
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public List<Point> getEmptySpots() {
		return emptySpots;
	}
	
	/**
	 * Gets if the board is full.
	 * 
	 * @return
	 */
	public boolean isFull() {
		return emptySpots.isEmpty();
	}
	
	public boolean boardfull(){
		
		
		return false;
		
		
	}
}
