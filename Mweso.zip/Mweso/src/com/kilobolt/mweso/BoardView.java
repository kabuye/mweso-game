package com.kilobolt.mweso;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class BoardView extends View {
	private GameBoard gameBoard;
	private BoardRenderer renderer;
	
	private void init() {
		// load graphics
		Resources res = getContext().getResources();
		renderer = new BoardRenderer(res);
		
		this.gameBoard = new GameBoard(3, 3);
	}
	
	public BoardView(Context context) {
		super(context);
		init();
	}
	
	public BoardView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}
	
	public BoardView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}
	
	/**
	 * Draws the board.
	 */
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		renderer.render(canvas, gameBoard);
	}

	public GameBoard getGameBoard() {
		return gameBoard;
	}

	public void setGameBoard(GameBoard gameBoard) {
		this.gameBoard = gameBoard;
	}
	
	public BoardRenderer getBoardRenderer() {
		return renderer;
	}

	public void resetGhostPiece() {
		getBoardRenderer().setGhostPiece(null);
	}
	
	public void renderGhostPiece(MotionEvent event) {
		Point p = getBoardRenderer().translatePixelToBoardCoordinates(getGameBoard(), (int)event.getX(), (int)event.getY());
		
		if(p != null && p != getBoardRenderer().getGhostPiece()) {
			getBoardRenderer().setGhostPiece(p);
			
			redrawView();
		}
	}

	public void redrawView() {
		invalidate();
		refreshDrawableState();
	}
}
