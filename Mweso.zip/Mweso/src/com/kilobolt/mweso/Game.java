package com.kilobolt.mweso;

import java.util.Collections;
import java.util.List;

import android.graphics.Point;

/**
 * Models a TicTacToe game.  This includes the game logic, making AI moves, keeping
 * track of the board and so forth.
 * 
 * @author kris
 *
 */
public class Game {
	private GameBoard gameBoard;

	private boolean twoPlayer;
	
	/**
	 * Creates a game model.
	 */
	public Game() {
		
	}
	
	/**
	 * Starts a new game, clearing the state of the old game.
	 * 
	 * @param width
	 * 	Board's width
	 * @param height
	 * 	Board's height
	 * @param twoPlayer
	 * 	Is this a two player game?
	 */
	public void newGame(int width, int height, boolean twoPlayer) {
		gameBoard = new GameBoard(width, height);
		this.twoPlayer = twoPlayer;
	}
	
	public boolean isTwoPlayer() {
		return twoPlayer;
	}
	
	/**
	 * Checks for a winning condition.  If found, returns the player who is winning.
	 * @return
	 * 	Winning player, or {@link Player#NO_PLAYER}
	 */
	public Player checkForWin() {
		Player p;
		int x;
		int y;
		
		// Search rows
		for(x = 0; x < gameBoard.getWidth(); x++) {
			p = gameBoard.get(x, 0);
			
			if(p != Player.NO_PLAYER) {
				boolean foundWinner = true;
				
				for(y = 1; y < gameBoard.getHeight(); y++) {
					if(gameBoard.get(x, y) != p) {
						foundWinner = false;
					}
				}
				
				if(foundWinner) {
					return p;
				}
			}
		}
		
		// Search columns
		for(y = 0; y < gameBoard.getHeight(); y++) {
			p = gameBoard.get(0, y);
			
			if(p != Player.NO_PLAYER) {
				boolean foundWinner = true;
				
				for(x = 1; x < gameBoard.getWidth(); x++) {
					if(gameBoard.get(x, y) != p) {
						foundWinner = false;
					}
				}
				
				if(foundWinner) {
					return p;
				}
			}
		}
		
		// Search diagnols
		p = gameBoard.get(0, 0);
		
		if(p != Player.NO_PLAYER) {
			boolean foundWinner = true;
			
			for(x = 1, y = 1; y < gameBoard.getHeight() && x < gameBoard.getWidth(); y++, x++) {
				if(gameBoard.get(x, y) != p) {
					foundWinner = false;
				}
			}
			
			if(foundWinner) {
				return p;
			}
		}
		
		p = gameBoard.get(gameBoard.getWidth() - 1, 0);
		
		if(p != Player.NO_PLAYER) {
			boolean foundWinner = true;
			
			for(x = gameBoard.getWidth() - 1, y = 0; y < gameBoard.getHeight() && x >= 0; y++, x--) {
				if(gameBoard.get(x, y) != p) {
					foundWinner = false;
				}
			}
			
			if(foundWinner) {
				return p;
			}
		}
		
		// No winner
		return Player.NO_PLAYER;
	}
	
	public GameBoard getGameBoard() {
		return gameBoard;
	}

	boolean executeComputerMove() {
		List<Point> emptySpots = getGameBoard().getEmptySpots();
		Collections.shuffle(emptySpots);
		
		Point p = emptySpots.get(0);
		getGameBoard().put(Player.PLAYER2, p.x, p.y);
		
		Player winner = checkForWin();
		if(winner != Player.NO_PLAYER) {
			return true;
		}
		
		return false;
	}
	
}
