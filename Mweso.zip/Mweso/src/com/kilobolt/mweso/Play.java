package com.kilobolt.mweso;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Point;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/**
 * Main activity for the TicTacToe game app.
 * 
 * @author Kris Healy
 */
public class Play extends Activity implements OnTouchListener {
	private Game game;
	private BoardView view;
	
    /** 
     * Called when the activity is first created. 
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        game = new Game();
        view = (BoardView)findViewById(R.id.boardview);
        view.setOnTouchListener(this);
        
        createNewGame();
    }

	private void createNewGame() {
		game.newGame(3, 3, false);
        view.setGameBoard(game.getGameBoard());
        
        view.redrawView();
	}
    
	/**
	 * Triggered by onTouch events.  This contains a lot of logic since moving from one part of the
	 * game to another requires user input.  Once the user input is received then things like
	 * win conditions are determined and the AI gets to move.
	 */
	
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// Is the View that was touched the same instance of the view showing the board?
		if(v == view) {		
			Point p;
			switch(event.getAction()) {
				case MotionEvent.ACTION_UP:
					view.resetGhostPiece();
					p = view.getBoardRenderer().translatePixelToBoardCoordinates(view.getGameBoard(), (int)event.getX(), (int)event.getY());
					
					if(p != null) {
						GameBoard gameBoard = game.getGameBoard();
						
						if(gameBoard.put(Player.PLAYER1, p.x, p.y)) {
							view.redrawView();
							
							Player winner = game.checkForWin();
							if(winner != Player.NO_PLAYER) {
								showWin(winner);
							} else if(!gameBoard.isFull()) {
								boolean computerWin = game.executeComputerMove();
								view.redrawView();
								
								if(computerWin) {
									showWin(Player.PLAYER2);
								}
							}
							
							// Check to see if it's game over because the board is full.
							if(winner == Player.NO_PLAYER && gameBoard.isFull()) {
								showWin(Player.NO_PLAYER);
							}
						}
					}
					break;
				case MotionEvent.ACTION_DOWN:
					view.renderGhostPiece(event);
					break;
				case MotionEvent.ACTION_MOVE:
					view.renderGhostPiece(event);
					break;
			}
		}
		
		return true;
	}

	/**
	 * Pops up a box telling the player who won.  Resets the game after they press the
	 * Okay button.
	 * 
	 * @param player
	 * 	Which player won, or if no player won NO_PLAYER
	 */
	private void showWin(Player player) {
		String msg;
		
		if(player == Player.PLAYER1) {
			msg = "You win!";
		} else if (player == Player.PLAYER2) {
			msg = "Computer wins!";
		} else {
			msg = "No winner!";
		}
		
		new AlertDialog.Builder(this)
			.setMessage(msg)
			.setTitle("Game Over")
			.setPositiveButton("Ok", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					createNewGame();
					view.redrawView();
				}
			})
			.show();
	}
}