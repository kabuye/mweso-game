/** Automatically generated file. DO NOT MODIFY */
package com.kilobolt.mweso;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}